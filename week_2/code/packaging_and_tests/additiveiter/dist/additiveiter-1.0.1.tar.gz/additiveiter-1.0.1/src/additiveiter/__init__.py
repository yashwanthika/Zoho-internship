def add_iter(args):
    result=0
    for item in args:
        result=result+item
    return result