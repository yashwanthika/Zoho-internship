# `additiveiter`

The `additiveiter`  can  be used to add iterative elements .


## Usage:
 from add-iter import add_iter

 add_iter([9,5,3,2,1])

